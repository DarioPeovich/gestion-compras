-- 007_crear_cc_movimientos.sql
-- Registro cronológico de todos los movimientos de la CC del proveedor.
-- saldo_acumulado se guarda en cada fila para consultas instantáneas.
-- Solo uno de factura_id / nota_id / pago_id tiene valor por fila, el resto NULL.
-- tipo: FACTURA | NOTA_CREDITO | NOTA_DEBITO | PAGO

CREATE TABLE cc_movimientos (
  id                SERIAL PRIMARY KEY,
  proveedor_id      INTEGER NOT NULL REFERENCES proveedores(id),
  factura_id        INTEGER REFERENCES facturas_compra(id),
  nota_id           INTEGER REFERENCES notas_credito_debito(id),
  pago_id           INTEGER REFERENCES pagos(id),
  tipo              VARCHAR(20) NOT NULL,
  fecha             DATE NOT NULL,
  debito            DECIMAL(19,6) NOT NULL DEFAULT 0,
  credito           DECIMAL(19,6) NOT NULL DEFAULT 0,
  saldo_acumulado   DECIMAL(19,6) NOT NULL,
  descripcion       VARCHAR(200),
  created_at        TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_cc_proveedor  ON cc_movimientos(proveedor_id);
CREATE INDEX idx_cc_fecha      ON cc_movimientos(fecha);
CREATE INDEX idx_cc_tipo       ON cc_movimientos(tipo);
CREATE INDEX idx_cc_factura    ON cc_movimientos(factura_id);
CREATE INDEX idx_cc_nota       ON cc_movimientos(nota_id);
CREATE INDEX idx_cc_pago       ON cc_movimientos(pago_id);
