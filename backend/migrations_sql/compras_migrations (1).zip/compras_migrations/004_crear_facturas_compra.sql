-- 004_crear_facturas_compra.sql
-- stock_actualizado=FALSE cuando ya existe remito asociado (stock ya fue actualizado).
-- stock_actualizado=TRUE cuando la factura llega sola (sin remito previo).
-- tipo_cbte: FA | FB | FC | FE | FM (facturas AFIP Argentina)
-- estado: PENDIENTE | PAGADA | PAGADA_PARCIAL | ANULADA

CREATE TABLE facturas_compra (
  id                SERIAL PRIMARY KEY,
  proveedor_id      INTEGER NOT NULL REFERENCES proveedores(id),
  tipo_cbte         VARCHAR(5) NOT NULL,
  punto_venta       INTEGER NOT NULL,
  nro_factura       INTEGER NOT NULL,
  fecha             DATE NOT NULL DEFAULT CURRENT_DATE,
  fecha_vto         DATE,
  subtotal          DECIMAL(19,6) NOT NULL DEFAULT 0,
  total             DECIMAL(19,6) NOT NULL DEFAULT 0,
  impuestos         JSONB,
  estado            VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE',
  stock_actualizado BOOLEAN NOT NULL DEFAULT FALSE,
  observaciones     TEXT,
  usuario_id        INTEGER NOT NULL,
  created_at        TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(proveedor_id, tipo_cbte, punto_venta, nro_factura)
);

CREATE TABLE facturas_detalle (
  id                  SERIAL PRIMARY KEY,
  factura_id          INTEGER NOT NULL REFERENCES facturas_compra(id),
  hfsql_articulos_id  INTEGER NOT NULL,
  articulo_codigo     VARCHAR(20) NOT NULL,
  articulo_descrip    VARCHAR(100) NOT NULL,
  cantidad            DECIMAL(14,3) NOT NULL,
  precio_costo        DECIMAL(19,6) NOT NULL,
  impuestos_linea     JSONB,
  created_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Tabla de asociación N:M entre remitos y facturas.
-- Una factura puede agrupar varios remitos.
-- Un remito puede estar en varias facturas (caso raro pero posible).
CREATE TABLE remitos_facturas (
  id          SERIAL PRIMARY KEY,
  remito_id   INTEGER NOT NULL REFERENCES remitos(id),
  factura_id  INTEGER NOT NULL REFERENCES facturas_compra(id),
  created_at  TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(remito_id, factura_id)
);

CREATE INDEX idx_fc_proveedor   ON facturas_compra(proveedor_id);
CREATE INDEX idx_fc_estado      ON facturas_compra(estado);
CREATE INDEX idx_fc_fecha_vto   ON facturas_compra(fecha_vto);
CREATE INDEX idx_fd_factura     ON facturas_detalle(factura_id);
CREATE INDEX idx_rf_remito      ON remitos_facturas(remito_id);
CREATE INDEX idx_rf_factura     ON remitos_facturas(factura_id);
