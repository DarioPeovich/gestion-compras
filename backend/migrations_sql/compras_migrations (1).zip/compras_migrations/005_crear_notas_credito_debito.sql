-- 005_crear_notas_credito_debito.sql
-- tipo: NC (nota de crédito) | ND (nota de débito)
-- NC reduce deuda, puede devolver stock.
-- ND aumenta deuda, generalmente no toca stock.
-- factura_id es nullable: puede referenciar una factura específica o ser general.

CREATE TABLE notas_credito_debito (
  id                SERIAL PRIMARY KEY,
  proveedor_id      INTEGER NOT NULL REFERENCES proveedores(id),
  factura_id        INTEGER REFERENCES facturas_compra(id),
  tipo              VARCHAR(2) NOT NULL CHECK (tipo IN ('NC', 'ND')),
  tipo_cbte         VARCHAR(5) NOT NULL,
  punto_venta       INTEGER NOT NULL,
  nro_comprobante   INTEGER NOT NULL,
  fecha             DATE NOT NULL DEFAULT CURRENT_DATE,
  importe           DECIMAL(19,6) NOT NULL,
  motivo            VARCHAR(200),
  impuestos         JSONB,
  stock_ajustado    BOOLEAN NOT NULL DEFAULT FALSE,
  observaciones     TEXT,
  usuario_id        INTEGER NOT NULL,
  created_at        TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(proveedor_id, tipo_cbte, punto_venta, nro_comprobante)
);

CREATE TABLE notas_detalle (
  id                  SERIAL PRIMARY KEY,
  nota_id             INTEGER NOT NULL REFERENCES notas_credito_debito(id),
  hfsql_articulos_id  INTEGER,
  articulo_codigo     VARCHAR(20),
  articulo_descrip    VARCHAR(100),
  cantidad            DECIMAL(14,3),
  precio_costo        DECIMAL(19,6),
  importe_linea       DECIMAL(19,6) NOT NULL,
  created_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_ncd_proveedor  ON notas_credito_debito(proveedor_id);
CREATE INDEX idx_ncd_factura    ON notas_credito_debito(factura_id);
CREATE INDEX idx_ncd_tipo       ON notas_credito_debito(tipo);
CREATE INDEX idx_nd_nota        ON notas_detalle(nota_id);
