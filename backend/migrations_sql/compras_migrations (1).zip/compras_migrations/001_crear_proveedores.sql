-- 001_crear_proveedores.sql
-- Proveedores: fuente de verdad en PostgreSQL.
-- hfsql_proveedores_id es el puente hacia el registro original en HFSQL.
-- articulo_codigo es el código estable generado desde articulosID (cast a texto).

CREATE TABLE proveedores (
  id                    SERIAL PRIMARY KEY,
  hfsql_proveedores_id  INTEGER UNIQUE,
  razon_social          VARCHAR(150) NOT NULL,
  cuit                  VARCHAR(20),
  articulo_codigo       VARCHAR(20) UNIQUE,
  condicion_pago        VARCHAR(50),
  dias_pago             INTEGER DEFAULT 0,
  email                 VARCHAR(100),
  telefono              VARCHAR(30),
  direccion             VARCHAR(200),
  contactos             JSONB,
  activo                BOOLEAN NOT NULL DEFAULT TRUE,
  created_at            TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_proveedores_hfsql    ON proveedores(hfsql_proveedores_id);
CREATE INDEX idx_proveedores_cuit     ON proveedores(cuit);
CREATE INDEX idx_proveedores_activo   ON proveedores(activo);
