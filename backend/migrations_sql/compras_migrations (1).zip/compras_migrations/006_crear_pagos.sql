-- 006_crear_pagos.sql
-- pagos: cabecera del pago al proveedor.
-- pagos_detalle: qué facturas cancela y por qué importe (parcial o total).
-- pagos_medios: con qué medios se pagó (transferencia, cheque, efectivo, etc).

CREATE TABLE pagos (
  id              SERIAL PRIMARY KEY,
  proveedor_id    INTEGER NOT NULL REFERENCES proveedores(id),
  fecha           DATE NOT NULL DEFAULT CURRENT_DATE,
  importe_total   DECIMAL(19,6) NOT NULL,
  observaciones   TEXT,
  usuario_id      INTEGER NOT NULL,
  created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE pagos_detalle (
  id                SERIAL PRIMARY KEY,
  pago_id           INTEGER NOT NULL REFERENCES pagos(id),
  factura_id        INTEGER NOT NULL REFERENCES facturas_compra(id),
  importe_aplicado  DECIMAL(19,6) NOT NULL,
  created_at        TIMESTAMP NOT NULL DEFAULT NOW()
);

-- medio: TRANSFERENCIA | CHEQUE | EFECTIVO | TARJETA | OTROS
CREATE TABLE pagos_medios (
  id          SERIAL PRIMARY KEY,
  pago_id     INTEGER NOT NULL REFERENCES pagos(id),
  medio       VARCHAR(20) NOT NULL,
  importe     DECIMAL(19,6) NOT NULL,
  referencia  VARCHAR(100),
  created_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_pagos_proveedor  ON pagos(proveedor_id);
CREATE INDEX idx_pagos_fecha      ON pagos(fecha);
CREATE INDEX idx_pd_pago          ON pagos_detalle(pago_id);
CREATE INDEX idx_pd_factura       ON pagos_detalle(factura_id);
CREATE INDEX idx_pm_pago          ON pagos_medios(pago_id);
