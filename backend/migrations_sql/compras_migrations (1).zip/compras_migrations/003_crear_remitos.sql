-- 003_crear_remitos.sql
-- El remito dispara la actualización de stock en HFSQL via WinDev API.
-- stock_actualizado se pone TRUE una vez confirmado el ingreso en HFSQL.
-- orden_compra_id es nullable: el remito puede llegar sin OC previa.
-- estado: PENDIENTE | CONFIRMADO | ANULADO

CREATE TABLE remitos (
  id                SERIAL PRIMARY KEY,
  proveedor_id      INTEGER NOT NULL REFERENCES proveedores(id),
  orden_compra_id   INTEGER REFERENCES ordenes_compra(id),
  nro_remito        VARCHAR(20) NOT NULL,
  fecha             DATE NOT NULL DEFAULT CURRENT_DATE,
  deposito_id       INTEGER NOT NULL,
  estado            VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE',
  stock_actualizado BOOLEAN NOT NULL DEFAULT FALSE,
  observaciones     TEXT,
  usuario_id        INTEGER NOT NULL,
  created_at        TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE remitos_detalle (
  id                  SERIAL PRIMARY KEY,
  remito_id           INTEGER NOT NULL REFERENCES remitos(id),
  hfsql_articulos_id  INTEGER NOT NULL,
  articulo_codigo     VARCHAR(20) NOT NULL,
  articulo_descrip    VARCHAR(100) NOT NULL,
  cantidad            DECIMAL(14,3) NOT NULL,
  precio_costo        DECIMAL(19,6),
  created_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_remitos_proveedor  ON remitos(proveedor_id);
CREATE INDEX idx_remitos_estado     ON remitos(estado);
CREATE INDEX idx_remitos_fecha      ON remitos(fecha);
CREATE INDEX idx_rd_remito          ON remitos_detalle(remito_id);
